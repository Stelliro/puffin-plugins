# PuffinPyEditor/plugins/find_replace/plugin_main.py
from search_replace_dialog import SearchReplaceDialog
from ui.editor_widget import EditorWidget

class FindReplacePlugin:
    def __init__(self, main_window):
        self.main_window = main_window
        self.api = main_window.puffin_api
        self.search_dialog = None
        self.find_action = self.api.add_menu_action("edit", "&Find/Replace...", self.show_dialog, "Ctrl+F", "fa5s.search")
        self.api.add_toolbar_action(self.find_action)
        self.find_action.setEnabled(False)

    def show_dialog(self):
        current_tab = self.main_window.tab_widget.currentWidget()
        if not isinstance(current_tab, EditorWidget):
            self.api.show_status_message("No editor open to search in.", 2000)
            return

        if not self.search_dialog:
            self.search_dialog = SearchReplaceDialog(self.main_window)
        self.search_dialog.show_dialog(current_tab)

    def on_tab_changed(self, index):
        is_editor = isinstance(self.main_window.tab_widget.widget(index), EditorWidget)
        self.find_action.setEnabled(is_editor)

def initialize(main_window):
    plugin_instance = FindReplacePlugin(main_window)
    main_window.tab_widget.currentChanged.connect(plugin_instance.on_tab_changed)
    # Ensure initial state is correct
    plugin_instance.on_tab_changed(main_window.tab_widget.currentIndex())
    return plugin_instance