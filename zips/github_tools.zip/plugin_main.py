# PuffinPyEditor/plugins/github_tools/plugin_main.py
import os, shutil, tempfile, git, sys, time
from PyQt6.QtWidgets import QInputDialog, QMessageBox, QProgressDialog
from PyQt6.QtCore import QProcess, QTimer
from new_release_dialog import NewReleaseDialog
from select_repo_dialog import SelectRepoDialog
from github_dialog import GitHubDialog
from utils import versioning
from app_core.settings_manager import settings_manager


class GitHubToolsPlugin:
    def __init__(self, main_window):
        self.main_window, self.api = main_window, main_window.puffin_api
        self.project_manager = self.api.get_manager("project")
        self.git_manager = self.api.get_manager("git")
        self.github_manager = self.api.get_manager("github")
        self._release_data = {}
        self.github_dialog = None
        self.build_process = None
        self._is_part_of_release = False
        self.api.log_info("GitHub Tools plugin initialized.")

        self.api.add_menu_action("tools", "Build Project Installer", self._show_build_installer_dialog,
                                 icon_name="fa5s.cogs")

    def _get_sc_panel(self):
        sc_plugin = self.main_window.plugin_manager.loaded_plugins.get('source_control_ui', {}).get('instance')
        return sc_plugin.source_control_panel if sc_plugin else None

    def _create_release(self, project_path):
        try:
            repo = git.Repo(project_path)
            if not repo.remotes: self.api.show_message("warning", "No Remote",
                                                       "This project is not linked to a remote repository."); return
            owner, repo_name = self.git_manager.parse_git_url(repo.remotes.origin.url)
            if not owner or not repo_name: self.api.show_message("critical", "Error",
                                                                 "Could not parse owner/repo from a valid GitHub remote URL."); return
            self._release_owner, self._release_repo_name = owner, repo_name
        except Exception as e:
            self.api.show_message("critical", "Error", f"Could not analyze repository: {e}"); return

        dialog = NewReleaseDialog(project_path, self.git_manager, self.main_window)
        if not dialog.exec(): self.api.show_status_message("Release cancelled.", 3000); return

        self._release_data = dialog.get_release_data()
        self._release_project_path = project_path
        if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(True,
                                                                    f"Creating tag '{self._release_data['tag']}'...")

        self.git_manager.git_success.connect(self._on_git_tag_created)
        self.git_manager.git_error.connect(self._on_release_step_failed)
        self.git_manager.create_tag(self._release_project_path, self._release_data['tag'], self._release_data['title'])

    def _on_git_tag_created(self, msg, data):
        if "Tag created" in msg:
            self.git_manager.git_success.disconnect(self._on_git_tag_created)
            if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(True,
                                                                        f"Pushing tag '{self._release_data['tag']}'...")
            self.git_manager.git_success.connect(self._on_git_tag_pushed)
            self.git_manager.push_specific_tag(self._release_project_path, self._release_data['tag'])

    def _on_git_tag_pushed(self, msg, data):
        if "Tag" in msg and "pushed" in msg:
            self.git_manager.git_success.disconnect(self._on_git_tag_pushed)
            if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(True, "Creating GitHub release...")
            self.github_manager.operation_success.connect(self._on_github_release_created)
            self.github_manager.operation_failed.connect(self._on_release_step_failed)
            self.github_manager.create_release(owner=self._release_owner, repo=self._release_repo_name,
                                               tag_name=self._release_data['tag'], name=self._release_data['title'],
                                               body=self._release_data['notes'],
                                               prerelease=self._release_data['prerelease'])

    def _on_github_release_created(self, msg, data):
        if "Release created" in msg:
            self.github_manager.operation_success.disconnect(self._on_github_release_created)
            self._release_info = data.get("release_data", {})
            self._release_upload_url = self._release_info.get("upload_url")
            if not self._release_upload_url:
                self._on_release_step_failed("GitHub did not provide an upload URL for assets.")
                return

            if self._release_data.get("build_installer"):
                self._is_part_of_release = True
                self._run_build_script(self._release_project_path)
            else:
                self._upload_assets()

    def _run_build_script(self, project_path):
        build_script_path = os.path.join(project_path, "installer", "build.bat")
        if not os.path.exists(build_script_path):
            self.api.show_message("warning", "Build Script Not Found", f"Could not find '{build_script_path}'.")
            if self._is_part_of_release: self._upload_assets()
            return

        self.build_progress = QProgressDialog("Building Application...", "This may take a moment...", 0, 0,
                                              self.main_window)
        self.build_progress.setCancelButton(None)
        self.build_progress.show()

        self.build_process = QProcess()
        self.build_process.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        self.build_process.finished.connect(self._on_pyinstaller_build_finished)
        self.api.log_info(f"Executing PyInstaller bundling script: {build_script_path}")
        self.build_process.start(build_script_path, [])

    def _on_pyinstaller_build_finished(self, exit_code, exit_status):
        if exit_code != 0:
            self.build_progress.close()
            self.api.show_message("error", "Build Failed", "PyInstaller bundling script failed.")
            if self._is_part_of_release: self._on_release_step_failed("PyInstaller build failed.")
            return

        self.build_progress.setLabelText("Creating Installer...")
        self._compile_nsis_installer()

    def _compile_nsis_installer(self):
        project_path = self.project_manager.get_active_project_path()
        nsis_script = os.path.join(project_path, "installer", "create_installer.nsi")

        makensis_exe = settings_manager.get("nsis_path")
        if not makensis_exe or not os.path.exists(makensis_exe):
            makensis_exe = shutil.which("makensis")

        if not makensis_exe:
            self.build_progress.close()
            error_msg = "NSIS 'makensis.exe' not found.\nPlease set the path in Preferences > Source Control > Build Tools."
            self.api.show_message("error", "Build Failed", error_msg)
            if self._is_part_of_release: self._on_release_step_failed("NSIS not found.")
            return

        version_str = self._release_data.get('tag', versioning.APP_VERSION).lstrip('v')
        command = [makensis_exe, f"/DVERSION={version_str}", nsis_script]

        self.nsis_process = QProcess()
        self.nsis_process.setWorkingDirectory(project_path)
        self.nsis_process.finished.connect(self._on_nsis_compile_finished)
        self.api.log_info(f"Executing NSIS compiler: {' '.join(command)} from '{project_path}'")
        self.nsis_process.start(command[0], command[1:])

    def _on_nsis_compile_finished(self, exit_code, exit_status):
        self.build_progress.close()
        if exit_code != 0:
            msg = "NSIS installer compilation failed."
            self.api.show_message("error", "Build Failed", msg)
            if self._is_part_of_release: self._on_release_step_failed(msg)
        else:
            self.api.show_status_message("Installer build successful.", 3000)
            if self._is_part_of_release: self._upload_assets()

    def _show_build_installer_dialog(self):
        project_path = self.project_manager.get_active_project_path()
        if not project_path:
            self.api.show_message("info", "No Project", "Please open a project to build.")
            return

        reply = QMessageBox.question(self.main_window, "Confirm Build",
                                     "This will run the project's full build and installer creation process. Continue?",
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel)
        if reply == QMessageBox.StandardButton.Yes:
            self._is_part_of_release = False
            self._release_data = {'tag': versioning.APP_VERSION, 'build_installer': True}
            self._run_build_script(project_path)

    def _upload_assets(self):
        assets_to_upload = []
        try:
            self._temp_zip_dir = tempfile.mkdtemp()
            zip_path = os.path.join(self._temp_zip_dir, f"{self._release_repo_name}-{self._release_data['tag']}.zip")
            if self.project_manager.create_project_zip(zip_path):
                assets_to_upload.append(zip_path)
            else:
                self.api.log_warning("Failed to create source code zip archive for release.")
        except Exception as e:
            self.api.log_error(f"Error creating source zip: {e}")

        if self._release_data.get("build_installer"):
            dist_path = os.path.join(self._release_project_path, "dist")
            version_str = self._release_data['tag'].lstrip('v')
            installer_name = f"PuffinPyEditor_v{version_str}_Setup.exe"
            installer_path = os.path.join(dist_path, installer_name)

            found = False
            for i in range(5):
                if os.path.exists(installer_path):
                    assets_to_upload.append(installer_path)
                    found = True
                    break
                time.sleep(1)

            if not found:
                self.api.log_warning(f"Could not find expected installer file after waiting: {installer_path}")

        if not assets_to_upload:
            self._on_release_step_failed("No release assets found or created to upload.")
            return

        self._assets_to_upload_queue = assets_to_upload
        self._upload_next_asset()

    def _upload_next_asset(self):
        if not self._assets_to_upload_queue:
            # --- MODIFIED: Use a QTimer.singleShot for the final message ---
            success_message = f"Release '{self._release_data['tag']}' was created and all assets uploaded."
            self.api.show_status_message(success_message, 5000)

            def show_final_dialog():
                QMessageBox.information(self.main_window, "Success", success_message)

            QTimer.singleShot(100, show_final_dialog)
            # --- END MODIFIED ---

            if versioning.write_new_version(self._release_data['tag']):
                self.main_window._update_window_title()
            self._cleanup_release_process()
            return

        asset_path = self._assets_to_upload_queue.pop(0)
        if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(True,
                                                                    f"Uploading {os.path.basename(asset_path)}...")
        self.github_manager.operation_success.connect(self._on_asset_uploaded)
        self.github_manager.upload_asset(self._release_upload_url, asset_path)

    def _on_asset_uploaded(self, msg, data):
        if "Asset uploaded" in msg:
            self.github_manager.operation_success.disconnect(self._on_asset_uploaded)
            self._upload_next_asset()

    def _on_release_step_failed(self, error_message):
        self.api.show_message("critical", "Release Failed", f"An error occurred: {error_message}")
        if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(False, f"Release failed.")
        self._cleanup_release_process()

    def _cleanup_release_process(self):
        try:
            self.git_manager.git_success.disconnect(); self.git_manager.git_error.disconnect(); self.github_manager.operation_success.disconnect(); self.github_manager.operation_failed.disconnect()
        except TypeError:
            pass
        if hasattr(self, '_assets_to_upload_queue'): self._assets_to_upload_queue.clear()
        if hasattr(self, 'build_process'): self.build_process = None
        if hasattr(self, '_temp_zip_dir') and os.path.exists(self._temp_zip_dir):
            shutil.rmtree(self._temp_zip_dir, ignore_errors=True)
            self.api.log_info(f"Cleaned up temporary release directory: {self._temp_zip_dir}")
        self._is_part_of_release = False

    def _publish_repo(self, local_path):
        if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(True, "Waiting for user input...")
        repo_name, ok = QInputDialog.getText(self.main_window, "Publish to GitHub", "Repository Name:",
                                             text=os.path.basename(local_path))
        if not ok or not repo_name:
            if sc_panel: sc_panel.set_ui_locked(False, "Publish cancelled."); return
        description, _ = QInputDialog.getText(self.main_window, "Publish to GitHub", "Description (optional):")
        is_private = QMessageBox.question(self.main_window, "Visibility", "Make this repository private?",
                                          QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                          QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes
        self.github_manager.operation_success.connect(
            lambda msg, data, path=local_path: self._on_repo_published(msg, data, path))
        self.github_manager.operation_failed.connect(
            lambda msg: self._get_sc_panel().set_ui_locked(False, f"Error: {msg}"))
        if sc_panel: sc_panel.set_ui_locked(True, f"Creating '{repo_name}' on GitHub...")
        self.github_manager.create_repo(repo_name, description, is_private)

    def _on_repo_published(self, msg, data, local_path):
        if "Repository" in msg and "created" in msg:
            self.github_manager.operation_success.disconnect();
            clone_url = data.get("clone_url")
            if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(True, "Linking and pushing...")
            self.git_manager.publish_repo(local_path, clone_url)

    def _link_repo(self, local_path):
        dialog = SelectRepoDialog(self.github_manager, self.main_window)
        if dialog.exec() and (repo_data := dialog.selected_repo_data):
            if clone_url := repo_data.get('clone_url'):
                if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(True, "Linking to remote...")
                self.git_manager.link_to_remote(local_path, clone_url)

    def _change_visibility(self, local_path):
        try:
            repo = git.Repo(local_path);
            if not repo.remotes: return
            owner, repo_name = self.git_manager.parse_git_url(repo.remotes.origin.url)
            if not owner or not repo_name: return
            is_private = QMessageBox.question(self.main_window, "Change Visibility", "Make repository private?",
                                              QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.No
            if sc_panel := self._get_sc_panel(): sc_panel.set_ui_locked(True, "Changing visibility...")
            self.github_manager.update_repo_visibility(owner, repo_name, is_private)
        except Exception as e:
            self.api.show_message("critical", "Error", f"Could not determine repository info: {e}")

    def _show_github_dialog(self):
        if not self.github_dialog:
            self.github_dialog = GitHubDialog(self.github_manager, self.git_manager, self.main_window)
            self.github_dialog.project_cloned.connect(lambda path: self.project_manager.open_project(path))
        self.github_dialog.show()


def initialize(main_window):
    plugin = GitHubToolsPlugin(main_window)
    plugin.api.add_menu_action("tools", "GitHub Repositories...", plugin._show_github_dialog, icon_name="fa5b.github")
    return plugin